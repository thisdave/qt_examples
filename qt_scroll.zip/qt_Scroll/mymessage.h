#ifndef _MY_MESSAGE_H
#define _MY_MESSAGE_H
#include <QtGui>

class MyMessage : public QDialog {
   Q_OBJECT
 public:
    MyMessage(QWidget * parent) ;
    

};
#endif /*MY Message_h*/