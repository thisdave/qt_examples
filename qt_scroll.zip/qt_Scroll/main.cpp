#include <QtGui>
#include <QtCore>
#include "mymessage.h"
#include <iostream>


int main(int argc, char* argv[])
 {  char c =' ';
    QApplication * myapp=new QApplication(argc,argv);
    QDialog * dialog1=new QDialog; 
    MyMessage msg(dialog1);
    msg.setWindowTitle("jó az ablak");
    msg.show();

    std::cout << "Kerek egy karaktert\n";
    std::cin  >> &c;         
}