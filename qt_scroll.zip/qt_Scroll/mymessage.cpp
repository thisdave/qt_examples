#include "mymessage.h"




MyMessage::MyMessage (QWidget *parent) : QDialog(parent)
{       QScrollArea *scroll = new QScrollArea(this);
        scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        scroll->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

        QWidget *viewport = new QWidget(this);
        scroll->setWidget(viewport);
        scroll->setWidgetResizable(true);
      
        QHBoxLayout *l = new QHBoxLayout(viewport);
        viewport->setLayout(l);

        // Add a layout for QDialog
        QHBoxLayout *dialog_layout = new QHBoxLayout(this);
        dialog_layout->addWidget(scroll); // add scroll to the QDialog's layout
        setLayout(dialog_layout);
     
        // show dialog
        show();

}